# Adafruit ZeroFFT Library [![Build Status](https://github.com/adafruit/Adafruit_ZeroFFT/workflows/Arduino%20Library%20CI/badge.svg)](https://github.com/adafruit/Adafruit_ILI9341/actions)

This is an FFT library for ARM cortex M0+ CPUs

Adafruit invests time and resources providing this open source code, please support Adafruit and open-source hardware by purchasing products from Adafruit!

Written by Dean Miller for Adafruit Industries.
MIT license, all text above must be included in any redistribution
